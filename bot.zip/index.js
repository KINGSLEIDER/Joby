// Require the necessary discord.js classes
const fs = require('node:fs');
const path = require('node:path');
const { Client, Intents, MessageAttachment, Collection } = require('discord.js');
const { token } = require('./config.json');


// Create a new client instance
const client = new Client({ intents: [Intents.FLAGS.GUILDS] });

client.commands = new Collection();
const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
	const filePath = path.join(commandsPath, file);
	const command = require(filePath);
	// Set a new item in the Collection
	// With the key as the command name and the value as the exported module
	client.commands.set(command.data.name, command);
}

// When the client is ready, run this code (only once)
client.once('ready', () => {
	console.log('Ready!');
});

//comandos
client.on('interactionCreate', async interaction => {
	if (!interaction.isCommand()) return;

	const command = client.commands.get(interaction.commandName);

	if (!command) return;

	try {
		await command.execute(interaction);
	} catch (error) {
		console.error(error);
		await interaction.reply({ content: 'Ocorreu um erro ao executar este comando!', ephemeral: true });
	}
});

//data base

// Import the functions you need from the SDKs you need
const { initializeApp } = require ("firebase/app");
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAJdCFd4gI1CY3xv3HhA2nfGOp_P3pqE1k",
  authDomain: "joby-68a77.firebaseapp.com",
  databaseURL: "https://joby-68a77-default-rtdb.firebaseio.com",
  projectId: "joby-68a77",
  storageBucket: "joby-68a77.appspot.com",
  messagingSenderId: "874494393322",
  appId: "1:874494393322:web:7740f91dafe65f951d1093"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Login to Discord with your client's token
client.login(token);
